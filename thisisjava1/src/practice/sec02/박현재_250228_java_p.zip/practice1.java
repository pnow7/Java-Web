package practice.sec02;

public class practice1 {

	public static void main(String[] args) {
		String myName = "박현재";
		String myAge = "27";
		String myHeight = "175";
		
		System.out.println("이름: "+myName+", 나이: "+myAge+", 키: "+myHeight);

	}

}

package practice.sec02;

public class practice2 {

	public static void main(String[] args) {
		10 //int형
		1. // double형
		6F //float형
		23d //double형
		14E10 //double형
		'a' //char형

	}

}

package practice.sec03;

public class practice16 {

	public static void main(String[] args) {
		System.out.println("*************************");
		System.out.println("*\t성적표\t\t*");
		System.out.println("*************************");
		System.out.println("* 국어\t\t50\t*");
		System.out.println("*************************");
		System.out.println("* 영어\t\t50\t*");
		System.out.println("*************************");
		System.out.println("* 수학\t\t50\t*");
		System.out.println("*************************");
		System.out.println("* 컴퓨터학과\t홍길동\t*");
		System.out.println("*************************");
	}

}

package practice.sec03;

public class practice18 {

	public static void main(String[] args) {
		System.out.println("1"); //1출력하고 개행
		System.out.println("2"); //2출력하고 개행
		System.out.println("3"); //3출력하고 개행
	}

}

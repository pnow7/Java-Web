package practice.sec03;

public class practice19 {

	public static void main(String[] args) {
		System.out.print("1"); //1출력
		System.out.print("2"); //1뒤에 바로 2 출력
		System.out.print("3"); //2뒤에 바로 3출력

	}

}

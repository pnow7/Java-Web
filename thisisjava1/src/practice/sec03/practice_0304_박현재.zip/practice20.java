package practice.sec03;

public class practice20 {

	public static void main(String[] args) {
		System.out.print("hello"); //hello 출력
		System.out.println(" World"); //hello 출력 후 한칸 띄우고 World 출력하고 개행
		System.out.println(" World"); //개행된 뒤 한칸 띄우고 World 출력하고 개행
		System.out.print("hello"); //World바로 뒤에 hello 출력 
		//hello World
		// World
		//hello

	}

}

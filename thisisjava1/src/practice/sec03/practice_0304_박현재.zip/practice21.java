package practice.sec03;

public class practice21 {

	public static void main(String[] args) {
		System.out.print("12"); //12출력
		System.out.println("34"); //12출력하고 바로 34출력 후 개행
		System.out.println("56"); //56출력 하고 개행
		//1234
		//56
	}

}

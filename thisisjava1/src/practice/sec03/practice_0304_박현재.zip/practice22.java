package practice.sec03;

public class practice22 {

	public static void main(String[] args) {
		System.out.println("hello");
		System.out.print("java");

	}

}

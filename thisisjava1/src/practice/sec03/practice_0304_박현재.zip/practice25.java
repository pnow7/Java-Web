package practice.sec03;

public class practice25 {
	public static void main(String[] args) {
		System.out.print("*");
		System.out.println("");
		System.out.print("*");
		System.out.print("*");
		System.out.println("");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println("");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.print("*");
		System.out.println("");
	}

}

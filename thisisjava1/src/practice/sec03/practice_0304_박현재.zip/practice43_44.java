package practice.sec03;

public class practice43_44 {

	public static void main(String[] args) {
		//43
		int a = 10;
		System.out.println(a); //int타입 a는 10이 저장되어있다. a를 출력하여 a인 값인 10을 출력하고 개행한다
		
		int b = 30;
		System.out.println(b); //int타입 b는 30이 저장되어있다. b를 출력하여 b인 값인 30을 출력하고 개행한다
		
		//44
		int b1 = 30;
		System.out.println(b+10); //int타입 b1에 10을 더하여 40을 출력하고 개행
		int c1 = 30;
		System.out.println(c1+c1); //int타입인 c1이 30을 저장하고 있다. 변수끼리 더하여(c1+c1) 60을 출력한다
		

	}

}

package practice.sec03;

public class practice45 {

	public static void main(String[] args) {
		int hello = 50;
		System.out.println(hello+30);
	}

}

package practice.sec03;

public class practice46 {

	public static void main(String[] args) {
		int d = 30;
		d = 60;
		System.out.println(d); //int타입 변수 d는 초기 30이였지만 d=60으로 변수값이 바뀌었다. 바뀐 변수값 d는 60을 출력하고 개행한다
		
		int i1 = 22;
		int i2 = 11;
		int i3 = 33;
		System.out.println(i1+i2+i3); //int타입 i1, i2, i3끼리 더하여 66(22+11+33)을 출력하고 개행한다

	}

}

package practice.sec03;

public class practice47 {

	public static void main(String[] args) {
		int world = 5;
		System.out.println(world);
		
		int a = 6;
		System.out.println(world+a);

	}

}

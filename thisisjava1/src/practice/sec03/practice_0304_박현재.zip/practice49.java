package practice.sec03;

public class practice49 {
	public static void main(String[] args) {
		int a = 5;
		int b = 6;
		System.out.println("a+b="+a+b); //문자열 a+b=출력하고 int타입인 변수 a를 5로 그대로 출력하고 변수 b도 6으로 그대로 출력후 개행 
	}

}

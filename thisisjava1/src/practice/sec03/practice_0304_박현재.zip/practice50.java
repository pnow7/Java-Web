package practice.sec03;

public class practice50 {

	public static void main(String[] args) {
		int a=5;
		System.out.println(a); //int 타입 변수 a는 5로 저장. 5로 저장된 a 출력후 개행
		a=3;
		System.out.println(a); //int 타입 a는 값이 5였지만 3으로 다시 정의하였다. 바뀐 값 3을 출력후 개행

	}

}

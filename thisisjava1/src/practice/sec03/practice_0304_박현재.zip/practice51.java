package practice.sec03;

public class practice51 {

	public static void main(String[] args) {
		int i = 5;
		System.out.println(a); //변수 a는 선언되지 않았다 컴파일 오류가 난다
		a = 6;
		System.out.println(a); // System.out.println(a); 가 없어도 변수 a는 타입이 선언되지않았으므로 컴파일 오류가 난다. 처음부터 오류가 발생하는 코드를 적어 컴파일 오류가 난다 
		int b = 5;
		System.out.println(a+b); //변수 b는 타입과 값이 선언되었지만 윗줄 부터 컴파일 오류가 나므로 실행되지 않는다
	}

}

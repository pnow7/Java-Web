package practice.sec03;

public class practice59 {

	public static void main(String[] args) {
		int a = 6;
		a = a + 3;
		System.out.println(a);

	}

}

package practice.sec03;

public class practice60 {

	public static void main(String[] args) {
		int a = 5;
		int b = 6;
		int sum = a + b;
		a = 7;
		System.out.println(sum+a+b);
		sum = a + b;
		System.out.println(sum+a+b);

	}

}

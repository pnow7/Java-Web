package practice.sec03;

import java.util.Scanner;
public class practice75 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int b = sc.nextInt();
		int c = sc.nextInt();
		int d = sc.nextInt();
		int result = (b+c)*d/2;
		System.out.println("총 비용 : " + result+"원");

	}

}

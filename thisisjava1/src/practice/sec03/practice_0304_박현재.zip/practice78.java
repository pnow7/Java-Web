package practice.sec03;

import java.util.Scanner;
public class practice78 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double tall = sc.nextDouble();
		double result = 100*tall;
	
		System.out.println(tall+"m는 " + result + "cm입니다");

	}

}

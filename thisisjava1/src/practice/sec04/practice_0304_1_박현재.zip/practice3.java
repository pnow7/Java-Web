package practice.sec04;

public class practice3 {

	public static void main(String[] args) {
		int pencils = 534;
		int students = 30;
		
		int pencilsPerStudent = pencils/30;
		System.out.println(pencilsPerStudent);
		
		int pencilsLeft = pencils%30;
		System.out.println(pencilsLeft);

	}

}

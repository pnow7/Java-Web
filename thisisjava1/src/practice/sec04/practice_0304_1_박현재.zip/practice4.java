package practice.sec04;

public class practice4 {

	public static void main(String[] args) {
		int value = 356;
		System.out.println(value-value%100);

	}

}

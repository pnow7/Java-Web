package practice.sec04;

public class practice5 {

	public static void main(String[] args) {
		int lengthTop = 5;
		int lengthBottom = 12;
		int height = 7;
		//double area = ((lengthTop+lengthBottom)*height/2.0);
		//double area = ((double)((lengthTop+lengthBottom)*height*1.0/2.0));
		//double area = ((double)(lengthTop+lengthBottom)*height/2.0));
		double area = ((double)((lengthTop+lengthBottom)*height/2.0));
		//1,2,3,4 모두 다 가능
		System.out.println(area);

	}

}
